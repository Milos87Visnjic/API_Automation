public class Infinite_forLoop {
    public static void main(String[] args) {
        //infinite for loop
        for (;;){
            System.out.println("Good");
        }

    }
}
