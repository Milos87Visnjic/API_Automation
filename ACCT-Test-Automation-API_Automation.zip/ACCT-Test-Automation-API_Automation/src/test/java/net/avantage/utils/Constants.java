package net.avantage.utils;

public class Constants {

    public static final String PLAYER_ID =ConfigurationReader.get("playerId");
    public static final String BASE_URL_SHOE =ConfigurationReader.get("baseUrl_Shoe");

    public static final String URL_API=ConfigurationReader.get("url_API");
}
